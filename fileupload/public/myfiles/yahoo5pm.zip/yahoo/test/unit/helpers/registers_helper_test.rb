require 'test_helper'

class RegistersHelperTest < ActionView::TestCase
end
